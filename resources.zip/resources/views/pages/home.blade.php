@extends('layouts.app')

@section('title', 'ঢাকা ম্যাগাজিন - হোম')

@section('content')

  {{-- ══ HERO — 3 COLUMNS ═══════════════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4">
    <div class="grid grid-cols-1 lg:grid-cols-[27%_46%_27%] border-t border-[#e5e5e5]">

      {{-- LEFT: list articles --}}
      <div class="py-4 pr-0 lg:pr-5 lg:border-r border-[#e5e5e5]">
        @if(isset($leftCol))
          @foreach($leftCol as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-3 border-b border-[#e5e5e5] last:border-b-0">
              <div class="flex-1 min-w-0">
                <span class="text-[#e2231a] font-bold text-[12px] block mb-0.5">{{ $a['category'] }} &bull;</span>
                <h3 class="font-serif font-bold text-[15px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-3">
                  {{ $a['title'] }}
                </h3>
                <div class="text-[11px] text-[#999] mt-1">{{ $a['time_ago'] }}</div>
              </div>
              @if(!empty($a['image_url']))
                <div class="w-[88px] h-[50px] shrink-0 overflow-hidden">
                  <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                </div>
              @endif
            </a>
          @endforeach
        @endif
      </div>

      {{-- CENTER --}}
      <div class="py-4 px-0 lg:px-5 lg:border-r border-[#e5e5e5]">
        {{-- Featured: image LEFT | headline + excerpt RIGHT --}}
        @if(isset($featured))
          <a href="{{ route('article.show', $featured['slug']) }}"
            class="group flex gap-4 mb-5 pb-5 border-b border-[#e5e5e5]">
            <div class="w-[55%] shrink-0 aspect-[16/9] overflow-hidden">
              <img src="{{ $featured['image_url'] }}" alt="{{ $featured['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
            </div>
            <div class="flex-1 flex flex-col pt-1">
              <span class="text-[#e2231a] font-bold text-[12px] uppercase mb-1 block">{{ $featured['category'] }}</span>
              <h2 class="font-serif font-bold text-[22px] leading-[1.25] text-[#111] group-hover:text-[#e2231a] transition-colors mb-2">
                {{ $featured['title'] }}
              </h2>
              <p class="text-[#555] text-[13px] line-clamp-3 leading-relaxed">{{ $featured['excerpt'] }}</p>
              <div class="text-[11px] text-[#999] mt-2">{{ $featured['time_ago'] }}</div>
            </div>
          </a>
        @endif

        {{-- 3-column grid --}}
        @if(isset($centerGrid))
          <div class="grid grid-cols-3 gap-x-4 gap-y-5">
            @foreach($centerGrid as $a)
              <a href="{{ route('article.show', $a['slug']) }}" class="group flex flex-col">
                <div class="w-full aspect-[16/9] overflow-hidden mb-1.5">
                  <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                </div>
                <h3 class="font-serif font-bold text-[13px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-2">
                  {{ $a['title'] }}
                </h3>
                <div class="text-[11px] text-[#999] mt-0.5">{{ $a['time_ago'] }}</div>
              </a>
            @endforeach
          </div>
        @endif
      </div>

      {{-- RIGHT: opinion + more --}}
      <div class="py-4 pl-0 lg:pl-5">
        <h3 class="font-serif font-bold text-[16px] text-[#111] border-b-2 border-[#e2231a] pb-1 mb-1">
          মতামত ও আরও খবর
        </h3>
        @if(isset($rightCol))
          @foreach($rightCol as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-3 border-b border-[#e5e5e5] last:border-b-0">
              <div class="flex-1 min-w-0">
                <span class="text-[#e2231a] font-bold text-[12px] block mb-0.5">{{ $a['category'] }} &bull;</span>
                <h3 class="font-serif font-bold text-[15px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-3">
                  {{ $a['title'] }}
                </h3>
                <div class="text-[11px] text-[#999] mt-1">{{ $a['time_ago'] }}</div>
              </div>
              @if(!empty($a['image_url']))
                <div class="w-[88px] h-[50px] shrink-0 overflow-hidden">
                  <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                </div>
              @endif
            </a>
          @endforeach
        @endif
      </div>
    </div>
  </div>

  {{-- ── ADVERTISEMENT BANNER ─────────────────────────────────── --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-3">
    <div class="w-full bg-[#f5f5f5] border border-[#e0e0e0] flex items-center justify-center h-[90px]">
      <span class="text-[#bbb] text-[12px] tracking-widest uppercase">বিজ্ঞাপন</span>
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ BANGLADESH ════════════════════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <x-section-header title="বাংলাদেশ" :moreUrl="route('category.show', 'জাতীয়')" />
    <div class="grid grid-cols-2 md:grid-cols-4 gap-5">
      @if(isset($bangladeshArticles))
        @foreach($bangladeshArticles as $a)
          <x-cards.grid :article="$a" :titleSize="15" />
        @endforeach
      @endif
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ SARADESH (সারাদেশ) — 3-column layout ═══════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <div class="flex items-center justify-between pb-2 mb-4 border-b border-[#e8e8e8]">
      <div class="flex items-center gap-3">
        <span class="section-icon"></span>
        <h2 class="font-serif font-extrabold text-[20px] text-[#e2231a] leading-none">সারাদেশ</h2>
      </div>
      <a href="{{ route('category.show', 'country') }}" class="text-[#333] text-[13px] hover:text-[#e2231a] transition-colors flex items-center gap-0.5">
        আরও <span class="text-[15px] leading-none ml-0.5">&rsaquo;</span>
      </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-[1fr_2.2fr_1.3fr] gap-0 divide-x divide-[#e5e5e5]">

      {{-- COL 1: grid cards (image + title only) --}}
      <div class="pr-5 flex flex-col justify-between gap-5">
        @if(isset($countryLeft))
          @foreach($countryLeft as $a)
            <a href="{{ route('article.show', $a['slug']) }}" class="group flex flex-col">
              <div class="w-full aspect-[16/9] overflow-hidden mb-2">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
              <h3 class="font-serif font-bold text-[15px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-3">
                {{ $a['title'] }}
              </h3>
            </a>
          @endforeach
        @endif
      </div>

      {{-- COL 2: hero --}}
      <div class="px-5">
        @if(isset($countryHero))
          <a href="{{ route('article.show', $countryHero['slug']) }}" class="group flex flex-col">
            <div class="w-full aspect-[16/9] overflow-hidden mb-3">
              <img src="{{ $countryHero['image_url'] }}" alt="{{ $countryHero['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
            </div>
            <h3 class="font-serif font-extrabold text-[21px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-2 mb-2">
              {{ $countryHero['title'] }}
            </h3>
            <p class="text-[#555] text-[13px] leading-relaxed line-clamp-2">
              {{ $countryHero['excerpt'] }}
            </p>
          </a>
        @endif
      </div>

      {{-- COL 3: horizontal list (title + small image, no category/time) --}}
      <div class="pl-5 flex flex-col divide-y divide-[#eeeeee]">
        @if(isset($countryRight))
          @foreach($countryRight as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-3 first:pt-0 last:pb-0">
              <h3 class="font-serif font-bold text-[14px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-3 flex-1">
                {{ $a['title'] }}
              </h3>
              <div class="w-[68px] h-[38px] shrink-0 overflow-hidden">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
            </a>
          @endforeach
        @endif
      </div>

    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ INTERNATIONAL ════════════════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <div class="flex items-center gap-3 mb-4 border-b border-[#e5e5e5] pb-2">
      <span class="section-icon"></span>
      <h2 class="font-serif font-extrabold text-[20px] text-[#111]">আন্তর্জাতিক</h2>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-[2fr_2fr_1fr] gap-0 divide-x divide-[#e5e5e5]">

      {{-- COL 1: big article with image + title + excerpt + time --}}
      <div class="pr-6">
        @if(isset($internationalBig))
          <a href="{{ route('article.show', $internationalBig['slug']) }}" class="group block">
            <div class="w-full aspect-[16/9] overflow-hidden mb-3">
              <img src="{{ $internationalBig['image_url'] }}" alt="{{ $internationalBig['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
            </div>
            <h3 class="font-serif font-extrabold text-[20px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors mb-2 line-clamp-3">
              {{ $internationalBig['title'] }}
            </h3>
            <p class="text-[#555] text-[13px] leading-relaxed line-clamp-3">{{ $internationalBig['excerpt'] }}</p>
            <div class="text-[11px] text-[#999] mt-2">{{ $internationalBig['time_ago'] }}</div>
          </a>
        @endif
      </div>

      {{-- COL 2: horizontal list (title + image, no category/time) --}}
      <div class="px-6 flex flex-col divide-y divide-[#f0f0f0]">
        @if(isset($internationalSmall))
          @foreach($internationalSmall as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
              <h3 class="font-serif font-extrabold text-[15px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-3 flex-1">
                {{ $a['title'] }}
              </h3>
              <div class="w-[72px] h-[40px] shrink-0 overflow-hidden">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
            </a>
          @endforeach
        @endif
      </div>

      {{-- COL 3: ad + 1 article --}}
      <div class="pl-6 flex flex-col gap-4">
        <div class="w-full flex flex-col items-center justify-center bg-[#f5f5f5] border border-[#e0e0e0] py-8 px-3">
          <span class="text-[#e2231a] text-[11px] font-bold tracking-wide mb-1">বিজ্ঞাপন</span>
        </div>
        @if(isset($internationalRight))
          <a href="{{ route('article.show', $internationalRight['slug']) }}"
            class="group flex items-start gap-3">
            <div class="flex-1">
              <h3 class="font-serif font-extrabold text-[14px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-4">
                {{ $internationalRight['title'] }}
              </h3>
              <div class="text-[11px] text-[#999] mt-1">{{ $internationalRight['time_ago'] }}</div>
            </div>
            <div class="w-[64px] h-[36px] shrink-0 overflow-hidden">
              <img src="{{ $internationalRight['image_url'] }}" alt="{{ $internationalRight['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
            </div>
          </a>
        @endif
      </div>

    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ OPINION (মতামত) ═════════════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <x-section-header title="মতামত" :moreUrl="route('category.show', 'মতামত')" />
    <div class="grid grid-cols-2 md:grid-cols-4 gap-5 divide-x divide-[#e5e5e5]">
      @if(isset($opinionArticles))
        @foreach($opinionArticles as $i => $a)
          <a href="{{ route('article.show', $a['slug']) }}"
            class="group flex flex-col {{ $i === 0 ? 'pr-5' : ($i === 3 ? 'pl-5' : 'px-5') }}">
            <div class="w-full aspect-[16/9] overflow-hidden mb-2">
              <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
            </div>
            @if(isset($opinionMeta) && isset($opinionMeta[$i]))
              <span class="text-[#e2231a] font-bold text-[11px] mb-0.5 uppercase tracking-wide">{{ $opinionMeta[$i]['tag'] }}</span>
              <p class="font-serif font-bold text-[13px] text-[#555] mb-1">{{ $opinionMeta[$i]['name'] }}</p>
            @endif
            <h3 class="font-serif font-bold text-[15px] text-[#111] leading-tight group-hover:text-[#e2231a] transition-colors line-clamp-3">
              {{ $a['title'] }}
            </h3>
            <div class="text-[11px] text-[#999] mt-1">{{ $a['time_ago'] }}</div>
          </a>
        @endforeach
      @endif
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ SPORTS (খেলাধুলা) — 3 panel ════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <div class="grid grid-cols-1 md:grid-cols-[220px_1fr_220px]">

      {{-- LEFT: Tabbed numbered list --}}
      <div class="border-r border-[#e5e5e5] pr-5 pt-1">
        <div class="flex mb-3">
          <button class="font-serif text-[14px] mr-5 pb-2 border-b-2 border-[#e2231a] text-[#111] font-extrabold transition-colors">পঠিত</button>
          <button class="font-serif text-[14px] mr-5 pb-2 border-b-2 border-transparent text-[#888] hover:text-[#111] transition-colors">আলোচিত</button>
          <button class="font-serif text-[14px] mr-5 pb-2 border-b-2 border-transparent text-[#888] hover:text-[#111] transition-colors">সুখবর</button>
        </div>
        @if(isset($sportsArticles))
          @foreach(array_slice($sportsArticles, 0, 5) as $i => $a)
            @php
              $bengaliNumbers = ['১','২','৩','৪','৫','৬','৭','৮','৯','১০'];
              $number = $bengaliNumbers[$i] ?? ($i + 1);
            @endphp
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-3 border-b border-[#f0f0f0] last:border-b-0">
              <span class="font-serif font-bold text-[34px] text-[#ddd] shrink-0 w-8 text-center leading-none mt-0.5">
                {{ $number }}
              </span>
              <div class="flex-1 pt-0.5">
                <h3 class="font-serif font-extrabold text-[14px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-3">
                  {{ $a['title'] }}
                </h3>
                <div class="text-[11px] text-[#999] mt-1">{{ $a['time_ago'] }}</div>
              </div>
            </a>
          @endforeach
        @endif
      </div>

      {{-- CENTER: hero overlay + 2-col grid --}}
      <div class="px-5 py-1 border-r border-[#e5e5e5]">
        <div class="flex items-center gap-2 mb-3">
          <span class="w-2.5 h-2.5 rounded-full bg-[#4a90d9] shrink-0"></span>
          <span class="font-serif font-extrabold text-[16px] text-[#111]">খেলা</span>
        </div>

        @if(isset($sportsArticles) && count($sportsArticles) > 0)
          <a href="{{ route('article.show', $sportsArticles[0]['slug']) }}" class="group block mb-4">
            <div class="relative w-full aspect-video overflow-hidden">
              <img src="{{ $sportsArticles[0]['image_url'] }}" alt="{{ $sportsArticles[0]['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
              <div class="absolute bottom-0 left-0 right-0 px-4 py-3">
                <h3 class="font-serif font-extrabold text-[20px] text-white leading-tight group-hover:text-[#f8a0a0] transition-colors line-clamp-2 drop-shadow">
                  {{ $sportsArticles[0]['title'] }}
                </h3>
                <div class="text-[12px] text-white/70 mt-1">{{ $sportsArticles[0]['time_ago'] }}</div>
              </div>
            </div>
          </a>

          <div class="grid grid-cols-2 gap-0">
            @foreach(array_slice($sportsArticles, 1, 2) as $i => $a)
              <a href="{{ route('article.show', $a['slug']) }}"
                class="group {{ $i === 1 ? 'pl-3 border-l border-[#e5e5e5]' : 'pr-3' }}">
                <div class="relative w-full aspect-[16/9] overflow-hidden">
                  <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                  <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent"></div>
                  <div class="absolute bottom-0 left-0 right-0 px-2.5 py-2">
                    <h3 class="font-serif font-extrabold text-[13px] text-white leading-tight group-hover:text-[#f8a0a0] transition-colors line-clamp-2 drop-shadow">
                      {{ $a['title'] }}
                    </h3>
                    <div class="text-[11px] text-white/60 mt-0.5">{{ $a['time_ago'] }}</div>
                  </div>
                </div>
              </a>
            @endforeach
          </div>
        @endif
      </div>

      {{-- RIGHT: sub-category articles --}}
      <div class="pl-5 pt-1">
        <div class="w-full bg-[#f5f5f5] border border-[#e0e0e0] flex items-center justify-center h-[80px]">
          <span class="text-[#bbb] text-[12px] tracking-widest uppercase">বিজ্ঞাপন</span>
        </div>
        <div class="mt-4">
          @if(isset($sportsSubcatArticles))
            @foreach($sportsSubcatArticles as $item)
              <a href="{{ route('article.show', $item['article']['slug']) }}"
                class="group flex items-start gap-2 py-3 border-b border-[#e5e5e5] last:border-b-0">
                <div class="flex-1 min-w-0">
                  <span class="text-[#e2231a] font-bold text-[12px]">{{ $item['subcat'] }} &bull;</span>
                  <h3 class="font-serif font-bold text-[14px] text-[#111] leading-tight group-hover:text-[#e2231a] transition-colors line-clamp-3 mt-0.5">
                    {{ $item['article']['title'] }}
                  </h3>
                  <div class="text-[11px] text-[#999] mt-1">{{ $item['article']['time_ago'] }}</div>
                </div>
                <div class="w-[70px] h-[39px] shrink-0 overflow-hidden">
                  <img src="{{ $item['article']['image_url'] }}" alt="{{ $item['article']['title'] }}" loading="lazy"
                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                </div>
              </a>
            @endforeach
          @endif
        </div>
      </div>
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ TECH (প্রযুক্তি) ═════════════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <x-section-header title="প্রযুক্তি" :moreUrl="route('category.show', 'প্রযুক্তি')" />
    <div class="grid grid-cols-2 md:grid-cols-4 gap-5">
      @if(isset($techArticles))
        @foreach($techArticles as $a)
          <x-cards.grid :article="$a" :titleSize="15" />
        @endforeach
      @endif
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ VIDEO — dark bg, 1 large left + 3 small right ════════ --}}
  <div class="w-full bg-[#1a1a1a] py-6">
    <div class="max-w-screen-xl mx-auto px-4">
      <div class="flex items-center justify-between mb-4 pb-2 border-b border-[#333]">
        <h2 class="font-serif font-bold text-[18px] text-white flex items-center gap-2">
          <svg viewBox="0 0 24 24" fill="#e2231a" class="w-5 h-5"><path d="M8 5v14l11-7z" /></svg>
          ভিডিও
        </h2>
        <a href="{{ route('category.show', 'বিনোদন') }}" class="text-[#e2231a] text-[13px] font-bold hover:underline">সব ভিডিও &rarr;</a>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-[1fr_320px] gap-6">
        @if(isset($videoFeatured))
          <a href="{{ route('article.show', $videoFeatured['slug']) }}" class="group flex flex-col">
            <div class="w-full overflow-hidden mb-2 relative aspect-video">
              <img src="{{ $videoFeatured['image_url'] }}" alt="{{ $videoFeatured['title'] }}" loading="lazy"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              <div class="absolute inset-0 flex items-center justify-center">
                <div class="bg-[#e2231a] rounded-full flex items-center justify-center opacity-90 group-hover:opacity-100 transition-opacity w-14 h-14">
                  <svg viewBox="0 0 24 24" fill="white" class="w-7 h-7 ml-1"><path d="M8 5v14l11-7z" /></svg>
                </div>
              </div>
            </div>
            <h3 class="font-serif font-bold text-[18px] text-white leading-tight group-hover:text-[#f8a0a0] transition-colors line-clamp-2">
              {{ $videoFeatured['title'] }}
            </h3>
            <div class="text-[11px] text-[#aaa] mt-1">{{ $videoFeatured['time_ago'] }}</div>
          </a>
        @endif
        @if(isset($videoSmall))
          <div class="flex flex-col gap-4 border-l-0 md:border-l border-[#333] md:pl-6">
            @foreach($videoSmall as $a)
              <a href="{{ route('article.show', $a['slug']) }}"
                class="group flex items-start gap-3">
                <div class="w-[110px] h-[62px] shrink-0 overflow-hidden relative">
                  <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                  <div class="absolute inset-0 flex items-center justify-center">
                    <div class="w-8 h-8 bg-[#e2231a] rounded-full flex items-center justify-center opacity-90">
                      <svg viewBox="0 0 24 24" fill="white" class="w-4 h-4 ml-0.5"><path d="M8 5v14l11-7z" /></svg>
                    </div>
                  </div>
                </div>
                <div class="flex-1">
                  <h3 class="font-serif font-bold text-[14px] text-white leading-tight group-hover:text-[#f8a0a0] transition-colors line-clamp-3">
                    {{ $a['title'] }}
                  </h3>
                  <div class="text-[11px] text-[#aaa] mt-1">{{ $a['time_ago'] }}</div>
                </div>
              </a>
            @endforeach
          </div>
        @endif
      </div>
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ ENTERTAINMENT (বিনোদন) ═══════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <x-section-header title="বিনোদন" :moreUrl="route('category.show', 'বিনোদন')" />

    <div class="grid grid-cols-1 lg:grid-cols-[1fr_2.2fr_1fr] gap-0 lg:divide-x divide-[#dcdfe3] bg-[#f4f6f8] border border-[#dcdfe3]">

      {{-- LEFT COL --}}
      <div class="flex flex-col p-4 pb-0">
        @if(isset($entertainmentLeft))
          @foreach($entertainmentLeft as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-4 border-b border-[#dcdfe3] first:pt-0 last:border-b-0 last:pb-4">
              <h3 class="font-serif font-bold text-[15px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-4 flex-1">
                {{ $a['title'] }}
              </h3>
              <div class="w-[90px] aspect-square shrink-0 overflow-hidden">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
            </a>
          @endforeach
        @endif
      </div>

      {{-- CENTER COL --}}
      <div class="p-4 flex flex-col">
        @if(isset($entertainmentHero))
          <a href="{{ route('article.show', $entertainmentHero['slug']) }}" class="group flex flex-col">
            <div class="w-full overflow-hidden mb-4">
              <div class="aspect-[16/9] w-full">
                <img src="{{ $entertainmentHero['image_url'] }}" alt="{{ $entertainmentHero['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
            </div>
            <h3 class="font-serif font-extrabold text-[24px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors mb-2.5">
              {{ $entertainmentHero['title'] }}
            </h3>
            <p class="text-[#555] text-[15px] leading-relaxed line-clamp-3">
              {{ $entertainmentHero['excerpt'] }}
            </p>
          </a>
        @endif
      </div>

      {{-- RIGHT COL --}}
      <div class="flex flex-col p-4 pb-0">
        @if(isset($entertainmentRight))
          @foreach($entertainmentRight as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-4 border-b border-[#dcdfe3] first:pt-0 last:border-b-0 last:pb-4">
              <h3 class="font-serif font-bold text-[15px] text-[#111] leading-snug group-hover:text-[#e2231a] transition-colors line-clamp-4 flex-1">
                {{ $a['title'] }}
              </h3>
              <div class="w-[90px] aspect-square shrink-0 overflow-hidden">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
            </a>
          @endforeach
        @endif
      </div>

    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ ECONOMY + LIFESTYLE side-by-side ════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-0 md:divide-x divide-[#e5e5e5]">
      <div class="md:pr-6">
        <x-section-header title="অর্থনীতি" :moreUrl="route('category.show', 'অর্থনীতি')" />
        @if(isset($economyArticles))
          @foreach($economyArticles as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-3 border-b border-[#e5e5e5] last:border-b-0">
              <div class="w-[130px] h-[73px] shrink-0 overflow-hidden">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
              <div class="flex-1 min-w-0">
                <span class="text-[#e2231a] font-bold text-[12px]">{{ $a['category'] }} &bull;</span>
                <h3 class="font-serif font-bold text-[16px] text-[#111] leading-tight group-hover:text-[#e2231a] transition-colors line-clamp-2 mt-0.5">
                  {{ $a['title'] }}
                </h3>
                <p class="text-[#555] text-[13px] line-clamp-2 mt-1 leading-relaxed">{{ $a['excerpt'] }}</p>
                <div class="text-[11px] text-[#999] mt-1">{{ $a['time_ago'] }}</div>
              </div>
            </a>
          @endforeach
        @endif
      </div>
      <div class="md:pl-6 mt-6 md:mt-0">
        <x-section-header title="লাইফস্টাইল" :moreUrl="route('category.show', 'লাইফস্টাইল')" />
        @if(isset($healthArticles))
          @foreach($healthArticles as $a)
            <a href="{{ route('article.show', $a['slug']) }}"
              class="group flex items-start gap-3 py-3 border-b border-[#e5e5e5] last:border-b-0">
              <div class="w-[130px] h-[73px] shrink-0 overflow-hidden">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
              <div class="flex-1 min-w-0">
                <span class="text-[#e2231a] font-bold text-[12px]">{{ $a['category'] }} &bull;</span>
                <h3 class="font-serif font-bold text-[16px] text-[#111] leading-tight group-hover:text-[#e2231a] transition-colors line-clamp-2 mt-0.5">
                  {{ $a['title'] }}
                </h3>
                <p class="text-[#555] text-[13px] line-clamp-2 mt-1 leading-relaxed">{{ $a['excerpt'] }}</p>
                <div class="text-[11px] text-[#999] mt-1">{{ $a['time_ago'] }}</div>
              </div>
            </a>
          @endforeach
        @endif
      </div>
    </div>
  </div>

  <div class="border-t-4 border-[#f0f0f0]"></div>

  {{-- ══ ঢাকা ম্যাগাজিন স্পেশাল ════════════════════════════ --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 py-5">
    <div class="flex items-center justify-between border-b-[3px] border-[#e2231a] pb-2 mb-4">
      <h2 class="font-serif font-bold text-[20px] text-[#111] leading-none">ঢাকা ম্যাগাজিন স্পেশাল</h2>
      <a href="{{ route('home') }}" class="text-[13px] font-bold text-[#555] hover:text-[#e2231a] transition-colors border border-[#ccc] px-3 py-1 rounded-sm hover:border-[#e2231a]">আরও ০</a>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-0 divide-x divide-[#e5e5e5]">
      @if(isset($specialArticles))
        @foreach($specialArticles as $i => $a)
          <a href="{{ route('article.show', $a['slug']) }}"
            class="group flex flex-col {{ $i === 0 ? 'pr-4' : ($i === 4 ? 'pl-4' : 'px-4') }}">
            @if($i === 0)
              <div class="relative w-full aspect-[16/9] overflow-hidden mb-3">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
                <div class="absolute bottom-0 left-0 right-0 p-3">
                  <h3 class="font-serif font-bold text-[16px] text-white leading-tight line-clamp-3 group-hover:text-[#f87171] transition-colors">
                    {{ $a['title'] }}
                  </h3>
                </div>
              </div>
            @else
              <div class="w-full aspect-[16/9] overflow-hidden mb-3">
                <img src="{{ $a['image_url'] }}" alt="{{ $a['title'] }}" loading="lazy"
                  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
              <h3 class="font-serif font-bold text-[15px] text-[#111] leading-tight group-hover:text-[#e2231a] transition-colors line-clamp-3 mb-1.5">
                {{ $a['title'] }}
              </h3>
            @endif

            <p class="text-[#555] text-[13px] leading-relaxed line-clamp-3">
              {{ $a['excerpt'] }}
            </p>
          </a>
        @endforeach
      @endif
    </div>
  </div>

  {{-- ── FOOTER AD ────────────────────────────────────────────── --}}
  <div class="w-full max-w-screen-xl mx-auto px-4 pb-4">
    <div class="w-full bg-[#f5f5f5] border border-[#e0e0e0] flex items-center justify-center h-[80px]">
      <span class="text-[#bbb] text-[12px] tracking-widest uppercase">বিজ্ঞাপন</span>
    </div>
  </div>

@endsection
