<header class="w-full bg-white flex flex-col font-serif" id="site-header">

  <div class="w-full max-w-screen-xl mx-auto px-4">
    <div class="flex flex-col md:flex-row items-center py-4 md:py-6">

      <div class="w-full md:w-[35%] flex justify-center md:justify-start mb-6 md:mb-0">
        <a href="{{ route('home') }}" class="text-[36px] md:text-[42px] font-serif font-bold text-[#111] tracking-tight leading-none">
          ঢাকা ম্যাগাজিন
        </a>
      </div>

      <div class="w-full md:w-[65%] flex flex-col sm:flex-row items-start sm:items-center">
        @if(isset($breakingStories) && count($breakingStories) > 0)
          @foreach($breakingStories as $index => $story)
            <a href="{{ route('article.show', $story['slug']) }}"
               class="group flex items-center p-2 flex-1 w-full {{ $index !== 0 ? 'sm:border-l border-[#e5e5e5] sm:pl-4' : '' }} {{ $index !== count($breakingStories) - 1 ? 'sm:pr-4 border-b sm:border-b-0 border-[#e5e5e5] mb-2 sm:mb-0' : '' }}">
              <div class="w-[80px] h-[45px] shrink-0 mr-3 overflow-hidden">
                <img src="{{ $story['image_url'] }}" alt="{{ $story['title'] }}"
                     class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]">
              </div>
              <h3 class="font-bold text-[14px] text-[#111] leading-tight line-clamp-2 group-hover:text-[#e2231a] transition-colors duration-150">
                {{ $story['title'] }}
              </h3>
            </a>
          @endforeach
        @endif
      </div>

    </div>
  </div>

  <div id="site-nav" class="w-full bg-[#1a1a1a] text-white z-40 relative transition-all">
    <div class="w-full max-w-screen-xl mx-auto px-4 h-[48px] flex items-center justify-between">

      <div class="flex items-center h-full">
        <nav class="hidden md:flex items-center h-full space-x-[14px]">
          <a href="{{ route('home') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">সর্বশেষ</a>
          <a href="{{ route('category.show', 'জাতীয়') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">বাংলাদেশ</a>
          <a href="{{ route('category.show', 'রাজনীতি') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">রাজনীতি</a>
          <a href="{{ route('category.show', 'বিশ্ব') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">বিশ্ব</a>
          <a href="{{ route('category.show', 'অর্থনীতি') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">বাণিজ্য</a>
          <a href="{{ route('category.show', 'মতামত') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">মতামত</a>
          <a href="{{ route('category.show', 'খেলা') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">খেলা</a>
          <a href="{{ route('category.show', 'বিনোদন') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">বিনোদন</a>
          <a href="{{ route('category.show', 'চাকরি') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">চাকরি</a>
          <a href="{{ route('category.show', 'লাইফস্টাইল') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">জীবনযাপন</a>
          <a href="{{ route('category.show', 'ভিডিও') }}" class="font-serif text-[14px] text-white hover:text-[#e2231a] transition-colors whitespace-nowrap py-1 border-b-2 border-transparent hover:border-[#e2231a]">ভিডিও</a>
        </nav>
      </div>

      <div class="flex items-center h-full space-x-3 md:space-x-4 text-[13px]">
        <button class="hidden md:flex items-center gap-1 text-white/70 hover:text-white transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <span class="text-[13px]">খুঁজুন</span>
        </button>

        <a href="#" class="hidden md:flex items-center gap-1 text-white/70 hover:text-white transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
          <span>ই-পেপার</span>
        </a>

        <a href="#" class="hidden md:flex items-center gap-1 text-white/70 hover:text-white transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
          <span>Eng</span>
        </a>

        <button class="hidden md:flex items-center gap-1 text-white/70 hover:text-white transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <span>Login</span>
        </button>

        <button id="theme-toggle" class="hidden md:flex items-center gap-1 text-white/70 hover:text-white transition-colors" aria-label="Toggle theme">
          <svg id="theme-icon-sun" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>
          <svg id="theme-icon-moon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="hidden"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
        </button>

        <button id="hamburger-btn" class="p-1 text-white hover:text-gray-300 ml-1">
          <svg id="icon-menu" xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
          <svg id="icon-close" xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="hidden"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        </button>
      </div>
    </div>
  </div>

  <div id="mobile-menu" class="hidden fixed inset-0 top-[140px] bg-white z-50 overflow-y-auto shadow-xl md:hidden">
    <nav class="flex flex-col">
      <a href="{{ route('home') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">সর্বশেষ</a>
      <a href="{{ route('category.show', 'জাতীয়') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">বাংলাদেশ</a>
      <a href="{{ route('category.show', 'রাজনীতি') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">রাজনীতি</a>
      <a href="{{ route('category.show', 'বিশ্ব') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">বিশ্ব</a>
      <a href="{{ route('category.show', 'অর্থনীতি') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">বাণিজ্য</a>
      <a href="{{ route('category.show', 'মতামত') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">মতামত</a>
      <a href="{{ route('category.show', 'খেলা') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">খেলা</a>
      <a href="{{ route('category.show', 'বিনোদন') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">বিনোদন</a>
      <a href="{{ route('category.show', 'চাকরি') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">চাকরি</a>
      <a href="{{ route('category.show', 'লাইফস্টাইল') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">জীবনযাপন</a>
      <a href="{{ route('category.show', 'ভিডিও') }}" class="text-[16px] font-serif font-bold text-[#111] border-b border-[#e5e5e5] p-4 hover:text-[#e2231a]">ভিডিও</a>
    </nav>
  </div>

</header>
